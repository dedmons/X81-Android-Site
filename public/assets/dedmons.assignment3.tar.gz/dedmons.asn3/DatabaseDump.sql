PRAGMA foreign_keys=OFF;
BEGIN TRANSACTION;
CREATE TABLE android_metadata (locale TEXT);
INSERT INTO "android_metadata" VALUES('en_US');
CREATE TABLE notes (_id integer primary key autoincrement, title text not null, body text not null, owner text not null);
INSERT INTO "notes" VALUES(1,'New Note 123','284ghxWPxJw/4vx6CEhaB+BuClwyEYG11TtmGiYQJwY=
','test');
INSERT INTO "notes" VALUES(2,'New Note 200','gJ/9nqZ6sq2HH+1eJvBKfQ==
','test');
INSERT INTO "notes" VALUES(3,'New Note','cG5AcqC7L756AXRumx/GlTJscy4RcaWn98WAZYQ+jko=
','test');
INSERT INTO "notes" VALUES(4,'New Note 106','mvUEEIEbbVtPI7c/cmi5YzmkJB8HGmdBozrm9WStaTs=
','test');
INSERT INTO "notes" VALUES(5,'New Note 656','xcgxH/HhAHt3uc1L9C6onDmkJB8HGmdBozrm9WStaTs=
','test');
INSERT INTO "notes" VALUES(6,'User 3','VbZUC4f4614BF6qCLfaOlw==
','test2');
INSERT INTO "notes" VALUES(7,'New share','cuO+WKZYqMFQHB4nQlZtbg==
','test2');
CREATE TABLE shared (_id integer primary key autoincrement, user_id text not null, note_id integer not null);
INSERT INTO "shared" VALUES(1,'test1',1);
INSERT INTO "shared" VALUES(2,'test2',1);
INSERT INTO "shared" VALUES(3,'test1',7);
CREATE TABLE users (_id integer primary key autoincrement, uname text not null, pass text not null);
INSERT INTO "users" VALUES(1,'test','1GKuSZsjGqhMs1r/MxaWJw==
');
INSERT INTO "users" VALUES(2,'test1','YWCE6mDa7P1o7I8KKI0WpQ==
');
INSERT INTO "users" VALUES(3,'test2','Ws/udEfQXMiXoEI8cdjBvw==
');
DELETE FROM sqlite_sequence;
INSERT INTO "sqlite_sequence" VALUES('notes',7);
INSERT INTO "sqlite_sequence" VALUES('users',3);
INSERT INTO "sqlite_sequence" VALUES('shared',3);
COMMIT;
