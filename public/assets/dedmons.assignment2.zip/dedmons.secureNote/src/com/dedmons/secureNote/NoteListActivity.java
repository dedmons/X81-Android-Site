package com.dedmons.secureNote;

import android.app.ListActivity;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.SharedPreferences.Editor;
import android.database.Cursor;
import android.os.Bundle;
import android.provider.Settings.Secure;
import android.util.Log;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.AdapterView;
import android.widget.AdapterView.OnItemClickListener;
import android.widget.ListView;
import android.widget.SimpleCursorAdapter;
import android.widget.TextView;

public class NoteListActivity extends ListActivity{
	private static final String LOG_TAG = "com.dedmons.asn1-NoteListActivity";
	public static final int INSERT_ID = Menu.FIRST;
	public static final int NOTE_LOADER = 0;
    private static final String PREFS = "com.dedmons.asn1-PREFS";

	
	private DataStore ds;

	private int mNoteNumber;
	private String user;

	@Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_note_list);
        ds = new DataStore(this);
        ds.open();
        
        SharedPreferences prefs = getSharedPreferences(PREFS, 0);
        user = prefs.getString("uname", "*");
        
        Log.v(LOG_TAG,"List for "+user);
        
        ListView lv = getListView();
        lv.setOnItemClickListener(new OnItemClickListener() {
        	public void onItemClick(AdapterView<?> parent, View view,
        	          int position, long id){
        		Log.v(LOG_TAG,"Item Clicked: "+position);
        		
        		String idString = ((TextView) view.findViewById(R.id.textView2)).getText().toString();
        		Log.v(LOG_TAG,"ID Clicked: "+idString);
        		
        		SharedPreferences prefs = getSharedPreferences(PREFS, 0);
        		Editor e = prefs.edit();
        		e.putString("NoteID", idString);
        		e.commit();
        		
        		String android_id = Secure.getString(getBaseContext().getContentResolver(),
                        Secure.ANDROID_ID);
        		
        		Cursor c = ds.fetchNote(Long.valueOf(idString));
        		String textCryptText = c.getString(2);
        		String textClearText = SimpleCrypto.decrypt(android_id, textCryptText);
        		String title = c.getString(1);
        		
//        		Log.v(LOG_TAG,"Crypt Text: "+textCryptText);
//        		Log.v(LOG_TAG,"Clear Text: "+textClearText);
//        		Log.v(LOG_TAG,"Title: "+title);
        		
        		Intent i = new Intent(getApplicationContext(), NoteEditActivity.class);
        		i.putExtra("noteTitle", title);
        		i.putExtra("noteText",textClearText);
        		startActivity(i);
        	}
		});
        
        fillData();
    }
	
	@Override
    public boolean onCreateOptionsMenu(Menu menu) {
        boolean result = super.onCreateOptionsMenu(menu);
        menu.add(0, INSERT_ID, 0, R.string.menu_insert);
        return result;
    }

	@Override
    public boolean onOptionsItemSelected(MenuItem item) {
        switch (item.getItemId()) {
        case INSERT_ID:
            createNote();
            return true;
        }
        return super.onOptionsItemSelected(item);
    }
	
	public void onResume(){
		super.onResume();
//		Log.v(LOG_TAG,"Resuming list activity");
		fillData();
	}
	
	private void createNote() {
        String noteName = "New Note";
        Intent i = new Intent(getApplicationContext(),NoteEditActivity.class);
        i.putExtra("noteTitle", noteName);
        i.putExtra("noteText", "");
        startActivity(i);
//        ds.createNote(noteName, "", user);
//        fillData();
//        Toast t = Toast.makeText(getApplicationContext(), "Created a new note", Toast.LENGTH_SHORT);
//        t.show();
    }

	private void fillData() {
		Cursor c = ds.fetchAllNotesForUser(user);
        startManagingCursor(c);

        String[] from = new String[] { ds.NOTE_TITLE,ds.NOTE_ROWID };
        int[] to = new int[] { R.id.textView1, R.id.textView2 };
        
        // Now create an array adapter and set it to display using our row
        SimpleCursorAdapter notes =
            new SimpleCursorAdapter(this, R.layout.note_view, c, from, to);
        setListAdapter(notes);
	}
}
