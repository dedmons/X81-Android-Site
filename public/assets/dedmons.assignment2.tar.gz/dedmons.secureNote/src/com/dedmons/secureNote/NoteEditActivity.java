package com.dedmons.secureNote;

import android.app.Activity;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.SharedPreferences.Editor;
import android.os.Bundle;
import android.provider.Settings.Secure;
import android.support.v4.app.NavUtils;
import android.util.Log;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.EditText;
import android.widget.Toast;

public class NoteEditActivity extends Activity {
	private static final String LOG_TAG = "com.dedmons.asn1-NoteEditActivity";
    private static final String PREFS = "com.dedmons.asn1-PREFS";

	private DataStore ds;
	private String user;
	private String noteID;
	
	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.activity_note_edit);
		// Show the Up button in the action bar.
		getActionBar().setDisplayHomeAsUpEnabled(true);
		
		ds = new DataStore(this);
        ds.open();
        
        SharedPreferences prefs = getSharedPreferences(PREFS, 0);
        user = prefs.getString("uname", "*");
        noteID = prefs.getString("NoteID", "New");
        
        Editor ed = prefs.edit();
        ed.remove("NoteID");
        ed.commit();
		
		Intent i = getIntent();
		
		EditText t = (EditText)findViewById(R.id.titleArea);
		t.setText(i.getStringExtra("noteTitle"));
		
		EditText e = (EditText)findViewById(R.id.textArea);
		e.setText(i.getStringExtra("noteText"));
	}

	@Override
	public boolean onCreateOptionsMenu(Menu menu) {
		// Inflate the menu; this adds items to the action bar if it is present.
//		getMenuInflater().inflate(R.menu.activity_note_edit, menu);
		return true;
	}

	@Override
	public boolean onOptionsItemSelected(MenuItem item) {
		switch (item.getItemId()) {
		case android.R.id.home:
			NavUtils.navigateUpFromSameTask(this);
			return true;
		}
		return super.onOptionsItemSelected(item);
	}

	public void cancelNote(View v){
		//TODO: cancel Note
		Log.v(LOG_TAG,"Cancel Note");
		Toast t = Toast.makeText(getApplicationContext(), "Note Canceled", Toast.LENGTH_SHORT);
		t.show();
		finish();
	}
	
	public void saveNote(View v){
		//TODO: save Note
		Log.v(LOG_TAG,"Save Note");
		
		String noteTitle = ((EditText) findViewById(R.id.titleArea)).getText().toString();
		String noteText = ((EditText) findViewById(R.id.textArea)).getText().toString();		
		String android_id = Secure.getString(getBaseContext().getContentResolver(),
                Secure.ANDROID_ID); 
		String noteTextCrypt = SimpleCrypto.encrypt(android_id, noteText);
			
		long res = 0;
		if(noteID.equalsIgnoreCase("new"))
			res = ds.createNote(noteTitle, noteTextCrypt, user);
		else{
			boolean r = ds.updateNote(Long.valueOf(noteID), noteTitle, noteTextCrypt);
			res = r?1:-1;
		}
		
		Toast t;
		if(res == -1)
			t = Toast.makeText(getApplicationContext(), "Error with saving note", Toast.LENGTH_SHORT);
		else
			t = Toast.makeText(getApplicationContext(), "Note Saved", Toast.LENGTH_SHORT);
		
		t.show();
		finish();
	}
	
	
}
