PRAGMA foreign_keys=OFF;
BEGIN TRANSACTION;
CREATE TABLE users (_id integer primary key autoincrement, uname text not null, pass text not null);
INSERT INTO "users" VALUES(1,'test','1GKuSZsjGqhMs1r/MxaWJw==
');
INSERT INTO "users" VALUES(2,'test1','YWCE6mDa7P1o7I8KKI0WpQ==
');
INSERT INTO "users" VALUES(3,'test2','Ws/udEfQXMiXoEI8cdjBvw==
');
DELETE FROM sqlite_sequence;
INSERT INTO "sqlite_sequence" VALUES('users',3);
COMMIT;
