package com.dedmons.helloworld;

import android.os.Bundle;
import android.app.Activity;
import android.view.View;
import android.view.Menu;
import android.view.Display;
import android.util.Log;
import java.util.Random;
import java.util.Timer;
import java.util.TimerTask;
import android.widget.Button;
import android.widget.TextView;
import android.graphics.Point;

public class MainActivity extends Activity {
	
	private static final String TAG = "MainActivity"; 
	private static final long DURATION = 500;
	
	
	private float label1StartX, label1StartY;
	private float label2StartX, label2StartY;
	
	private View.OnClickListener startAnimationAction = new View.OnClickListener() {
		@Override
		public void onClick(View v) {
			Log.i(TAG,"Start Animation pressed");
	    	Button b = (Button)v;
	    	b.setText(R.string.button_reset);
	    	b.setOnClickListener(resetAnimationAction);
	    	
	    	randTimer = new Timer("RandTimer");
	    	task = new TimerTask() {
	    		public void run() {
	    			randomizeViews();
	    		}
	    	};
	        randTimer.scheduleAtFixedRate(task, 0, DURATION*2);
		}
	};
	
	private View.OnClickListener resetAnimationAction = new View.OnClickListener() {
		@Override
		public void onClick(View v) {
			Log.i(TAG,"Reset Animation pressed");
	    	Button b = (Button)v;
	    	b.setText(R.string.button_start);
	    	b.setOnClickListener(startAnimationAction);
	    	
	    	randTimer.cancel();
	    	resetViews();
		}
	};
	
	private TimerTask task;
	
	private Timer randTimer;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        final Button b = (Button) findViewById(R.id.button1);
        
        b.setOnClickListener(startAnimationAction);
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        // Inflate the menu; this adds items to the action bar if it is present.
        getMenuInflater().inflate(R.menu.activity_main, menu);
        return true;
    }
    
    private void randomizeViews(){
    	Random r = new Random();
    	
    	Display display = getWindowManager().getDefaultDisplay();
    	Point size = new Point();
    	display.getSize(size);
    	int width = size.x;
    	int height = size.y;

    	Log.d(TAG,"width: "+width+" height: "+height);
    	
//    	final Button b = (Button) findViewById(R.id.button1);
        final TextView t1 = (TextView) findViewById(R.id.textView2);
        final TextView t2 = (TextView) findViewById(R.id.textView3);
        
//        buttonStartX = b.getLeft();
//        buttonStartY = b.getTop();
        label1StartX = t1.getLeft();
        label1StartY = t1.getTop();
        label2StartX = t2.getLeft();
        label2StartY = t2.getTop();
        
//        Log.d(TAG,"Left: "+label1StartX+" Top: "+label1StartY);
        
        t1.animate().setDuration(DURATION).x(r.nextInt(width-50)).withLayer();
        t1.animate().setDuration(DURATION).y(r.nextInt(height-50)).withLayer();
    	
        t2.animate().setDuration(DURATION).x(r.nextInt(width-50)).withLayer();
        t2.animate().setDuration(DURATION).y(r.nextInt(height-50)).withLayer();
    }
    
    private void resetViews(){
//    	final Button b = (Button) findViewById(R.id.button1);
        final TextView t1 = (TextView) findViewById(R.id.textView2);
        final TextView t2 = (TextView) findViewById(R.id.textView3);
        
        
        t1.animate().setDuration(DURATION).x(label1StartX).withLayer();
        t1.animate().setDuration(DURATION).y(label1StartY).withLayer();
    	
        t2.animate().setDuration(DURATION).x(label2StartX).withLayer();
        t2.animate().setDuration(DURATION).y(label2StartY).withLayer();
    }
    
}
