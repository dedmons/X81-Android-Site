package com.dedmons.secureNote;

import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.support.v4.app.FragmentActivity;
import android.util.Log;
import android.view.Menu;
import android.view.MenuItem;

public class NoteListActivity extends FragmentActivity {
	private static final String LOG_TAG = "com.dedmons.asn1-NoteListActivity";
	public static final int INSERT_ID = Menu.FIRST;
	public static final int NOTE_LOADER = 0;
    private static final String PREFS = "com.dedmons.asn1-PREFS";

	
	private DataCoordinator ds;

	private int mNoteNumber;
	private String user;
	private String tag;

	@Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.fragment_home_screen);
        
        SharedPreferences prefs = getSharedPreferences(PREFS, 0);
        user = prefs.getString("uname", "*");
        
        Log.v(LOG_TAG,"List for "+user);
    }
	
	@Override
    public boolean onCreateOptionsMenu(Menu menu) {
        boolean result = super.onCreateOptionsMenu(menu);
        menu.add(0, INSERT_ID, 0, R.string.menu_insert);
        return result;
    }

	@Override
    public boolean onOptionsItemSelected(MenuItem item) {
        switch (item.getItemId()) {
        case INSERT_ID:
            createNote();
            return true;
        }
        return super.onOptionsItemSelected(item);
    }
	
	public void onResume(){
		super.onResume();
//		fillData();
	}
	
	private void createNote() {
        String noteName = "New Note";
        Intent i = new Intent(getApplicationContext(),NoteEditActivity.class);
        i.putExtra("noteTitle", noteName);
        i.putExtra("noteText", "");
        startActivity(i);
    }

//	private void fillData() {
//		Cursor c = null;
//		
//		if(tag.equalsIgnoreCase("own")){
//			c = ds.fetchAllNotesForUser(user);
//		}
//		else if (tag.equalsIgnoreCase("shared")){
//			c = ds.fetchAllNotesForUser(user);
//		}
//		
//        startManagingCursor(c);
//        
//        String[] from = new String[] { ds.NOTE_TITLE,ds.NOTE_ROWID };
//        int[] to = new int[] { R.id.titleText, R.id.idText };
//        
//        // Now create an array adapter and set it to display using our row
//        SimpleCursorAdapter notes =
//            new SimpleCursorAdapter(this, R.layout.note_view, c, from, to);
//        
//        setListAdapter(notes);
//	}
}
