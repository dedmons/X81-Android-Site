package com.dedmons.secureNote;

import java.util.ArrayList;
import java.util.List;

import android.annotation.SuppressLint;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.SharedPreferences.Editor;
import android.database.Cursor;
import android.graphics.Color;
import android.os.Bundle;
import android.provider.Settings.Secure;
import android.support.v4.app.ListFragment;
import android.support.v4.app.LoaderManager.LoaderCallbacks;
import android.support.v4.content.AsyncTaskLoader;
import android.support.v4.content.Loader;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.ListView;
import android.widget.TextView;

@SuppressLint("ValidFragment")
public class MyListFragment extends ListFragment implements
		LoaderCallbacks<Void> {
	private static final String LOG_TAG = "com.dedmons.asn1-NoteListActivity";
	private static final String PREFS = "com.dedmons.asn1-PREFS";

	private String myTag;
	private String user;
	private int totalElements;
	private int position;

	private Cursor ownedCursor;
	private Cursor sharedCursor;
	private LayoutInflater inflater;
	private MyAdapter adapter;
	private ArrayList<String> items;
	private ArrayList<String> ids;

	private DataCoordinator dc;

	public MyListFragment() {
	}

	public MyListFragment(String tag) {
		myTag = tag;
	}

	public void onResume() {
		super.onResume();
		Log.v(LOG_TAG, "On Resume");
		
		items = new ArrayList<String>();
		ids = new ArrayList<String>();
		adapter = new MyAdapter(getActivity(), items, ids);
		getListView().setAdapter(adapter);

		getLoaderManager().initLoader(0, null, this);
		getLoaderManager().restartLoader(0, null, this);
		
		adapter.notifyDataSetChanged();
	}

	@Override
	public void onActivityCreated(Bundle savedInstanceState) {
		super.onActivityCreated(savedInstanceState);

		// IMPORTANT : this is to save the state across screen configuration
		// changes
//		setRetainInstance(true);

		SharedPreferences prefs = getActivity().getSharedPreferences(PREFS, 0);
		user = prefs.getString("uname", "*");

		// initialize the database for use
		dc = new DataCoordinator(getActivity());
		dc.open();

		ownedCursor = dc.fetchAllNotesForUser(user);
		sharedCursor = dc.fetchAllNotesSharedWithUser(user);

		Log.i(LOG_TAG, "My Notes: " + ownedCursor.getCount());
		Log.i(LOG_TAG, "shared Notes: " + sharedCursor.getCount());

		if (myTag.equals("Own Notes")) {
			totalElements = ownedCursor.getCount();
			Log.v("testing", "TOTAL ELEMENTS : " + totalElements);
		}
		if (myTag.equals("Shared Notes")) {
			totalElements = sharedCursor.getCount();
			Log.v("testing", "TOTAL ELEMENTS : " + totalElements);
		}

		inflater = LayoutInflater.from(getActivity());
	}

	@Override
	public Loader<Void> onCreateLoader(int arg0, Bundle arg1) {
		AsyncTaskLoader<Void> loader = new AsyncTaskLoader<Void>(getActivity()) {
			@Override
			public Void loadInBackground() {
				try {
					// simulate some time consuming operation going on in the
					// background
					Thread.sleep(600);
				} catch (InterruptedException e) {
				}
				return null;
			}
		};

		loader.forceLoad();
		return loader;
	}

	@Override
	public void onLoadFinished(Loader<Void> loader, Void result) {
		// add the new item and let the adapter know so it can refresh the view
		// first, construct the string to be placed in the list adapter
		String entry = null;

		items.clear();
		ids.clear();
		adapter.clear();

		if (myTag.equals("Own Notes")) {
			ownedCursor.moveToFirst();

			while (!ownedCursor.isAfterLast()) {
				entry = ownedCursor.getString(1);
				adapter.add(entry);
				ids.add(ownedCursor.getString(0));
				ownedCursor.moveToNext();
			}
			adapter.notifyDataSetChanged();

			Log.d(LOG_TAG, "---- DONE LOADING NOTES ----");

		}
		if (myTag.equals("Shared Notes")) {
			sharedCursor.moveToFirst();

			while (!sharedCursor.isAfterLast()) {
				entry = sharedCursor.getString(1);
				adapter.add(entry);
				ids.add(sharedCursor.getString(0));
				Log.i(LOG_TAG,"ENTRY: "+entry);
				sharedCursor.moveToNext();
			}
			adapter.notifyDataSetChanged();

			Log.d(LOG_TAG, "---- DONE LOADING SHARED NOTES ----");
		}
		setListShown(true);
		loader.forceLoad();
	}

	@Override
	public void onListItemClick(ListView lView, View view, int position, long id) {
		super.onListItemClick(lView, view, position, id);

		String idString = ids.get(position);
		Log.v(LOG_TAG, "Note ID: " + idString);

		SharedPreferences prefs = getActivity().getSharedPreferences(PREFS, 0);
		Editor e = prefs.edit();
		e.putString("NoteID", idString);
		e.commit();

		String android_id = Secure.getString(getActivity().getBaseContext()
				.getContentResolver(), Secure.ANDROID_ID);

		Cursor c = dc.fetchNote(Long.valueOf(idString));
		String textCryptText = c.getString(2);
		String textClearText = SimpleCrypto.decrypt(android_id, textCryptText);
		String title = c.getString(1);

		// Log.v(LOG_TAG,"Crypt Text: "+textCryptText);
		// Log.v(LOG_TAG,"Clear Text: "+textClearText);
		// Log.v(LOG_TAG,"Title: "+title);

		Intent i = new Intent(getActivity().getApplicationContext(),
				NoteEditActivity.class);
		i.putExtra("NoteID", idString);
		i.putExtra("noteTitle", title);
		i.putExtra("noteText", textClearText);
		startActivity(i);
		getActivity().finish();
	}

	@Override
	public void onLoaderReset(Loader<Void> arg0) {
		Log.v(LOG_TAG,"Loader reset");
		arg0.forceLoad();
	}

	private class MyAdapter extends ArrayAdapter<String> {

		private List<String> ids;
		
		public MyAdapter(Context context, List<String> elements, List<String> ids) {
			super(context, R.layout.list_item, R.id.text, elements);
			this.ids = ids;
		}

		public View getView(int position, View convertView, ViewGroup parent) {
			View view = convertView;
			ViewCache viewCache;

			if (view == null) {
//				view = inflater.inflate(R.layout.list_item, null);
				view = inflater.inflate(R.layout.note_view, null);
				viewCache = new ViewCache(view);
				view.setTag(viewCache);
			} else {
				viewCache = (ViewCache) view.getTag();
			}

			 viewCache.getTextView().setText( getItem(position) );
			 viewCache.getIDView().setText( ids.get(position));

			// if ( position % 2 == 0 )
			// viewCache.getBar().setBackgroundColor(Color.rgb(255, 120, 0));
			// if ( position % 2 == 1 )
			// viewCache.getBar().setBackgroundColor(Color.rgb(100, 30, 136));

			return view;
		}
	}

	private class ViewCache {
		private final View rootView;
		private TextView text;
		private TextView idView;
		private View bar;

		public ViewCache(View root) {
			rootView = root;
		}

		public TextView getTextView() {
			if (text == null) {
				text = (TextView) rootView.findViewById(R.id.text);
			}
			return text;
		}

		public TextView getIDView(){
			if (idView == null){
				idView = (TextView) rootView.findViewById(R.id.idText);
			}
			return idView;
		}
		
		public View getBar() {
			if (bar == null) {
				// bar = rootView.findViewById(R.id.bar);
			}
			return bar;
		}
	}

}
