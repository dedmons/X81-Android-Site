package com.dedmons.assignment1;

import android.app.ListActivity;
import android.content.SharedPreferences;
import android.database.Cursor;
import android.os.Bundle;
import android.util.Log;
import android.view.Menu;
import android.view.MenuItem;
import android.widget.SimpleCursorAdapter;

public class NoteListActivity extends ListActivity{
	private static final String LOG_TAG = "com.dedmons.asn1-NoteListActivity";
	public static final int INSERT_ID = Menu.FIRST;
	public static final int NOTE_LOADER = 0;
    private static final String PREFS = "com.dedmons.asn1-PREFS";

	
	private DataStore ds;

	private int mNoteNumber;
	private String user;

	@Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_note_list);
        ds = new DataStore(this);
        ds.open();
        
        SharedPreferences prefs = getSharedPreferences(PREFS, 0);
        user = prefs.getString("uname", "*");
        
        Log.v(LOG_TAG,"List for "+user);
        
        fillData();
    }
	
	@Override
    public boolean onCreateOptionsMenu(Menu menu) {
        boolean result = super.onCreateOptionsMenu(menu);
        menu.add(0, INSERT_ID, 0, R.string.menu_insert);
        return result;
    }

	@Override
    public boolean onOptionsItemSelected(MenuItem item) {
        switch (item.getItemId()) {
        case INSERT_ID:
            createNote();
            return true;
        }
       
        return super.onOptionsItemSelected(item);
    }
	
	private void createNote() {
        String noteName = "Note " + mNoteNumber++;
        ds.createNote(noteName, "", user);
        fillData();
    }

	private void fillData() {
		Cursor c = ds.fetchAllNotesForUser(user);
        startManagingCursor(c);

        String[] from = new String[] { ds.NOTE_TITLE };
        int[] to = new int[] { R.id.text1 };
        
        // Now create an array adapter and set it to display using our row
        SimpleCursorAdapter notes =
            new SimpleCursorAdapter(this, R.layout.note_view, c, from, to);
        setListAdapter(notes);
	}
}
