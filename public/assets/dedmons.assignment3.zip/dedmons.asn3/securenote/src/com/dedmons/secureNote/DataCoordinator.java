package com.dedmons.secureNote;

import java.util.ArrayList;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.SQLException;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;
import android.util.Log;

public class DataCoordinator {
	
	private static final String LOG_TAG = "com.dedmons.asn1-DataStore";
	private static final String PREFS = "com.dedmons.asn1-PREFS";

	private static DatabaseHelper dbHelper;
	private SQLiteDatabase db;

	public static final String NOTE_ROWID = "_id";
	public static final String NOTE_TITLE = "title";
	public static final String NOTE_BODY = "body";
	public static final String NOTE_OWNER = "owner";

	public static final String USER_ID = "uname";
	public static final String USER_PASS = "pass";
	public static final String USER_ROWID = "_id";

	public static final String SHARED_UID = "user_id";
	public static final String SHARED_NID = "note_id";
	public static final String SHARED_ROWID = "_id";

	private static final String USERS_CREATE = "create table users (_id integer primary key autoincrement, "
			+ "uname text unique not null, pass text not null);";
	private static final String NOTES_CREATE = "create table notes (_id integer primary key autoincrement, "
			+ "title text not null, body text not null, owner text not null);";
	private static final String SHARED_CREATE = "create table shared (_id integer primary key autoincrement, "
			+ "user_id text not null, note_id integer not null);";

	private static final String DATABASE_NAME = "dedmons.asn1.data";
	private static final String NOTES_TABLE = "notes";
	private static final String USER_TABLE = "users";
	private static final String SHARED_TABLE = "shared";
	private static final int DATABASE_VERSION = 2;

	private final Context mCtx;

	private static class DatabaseHelper extends SQLiteOpenHelper {

		DatabaseHelper(Context context) {
			super(context, DATABASE_NAME, null, DATABASE_VERSION);
		}

		@Override
		public void onCreate(SQLiteDatabase db) {
			// db.execSQL("DROP TABLE IF EXISTS notes");
			db.execSQL(USERS_CREATE);
			db.execSQL(NOTES_CREATE);
			db.execSQL(SHARED_CREATE);
		}

		@Override
		public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {
			if (oldVersion == 1 && newVersion == 2) {
				Log.i(LOG_TAG,
						"Upgrading database from version "
								+ oldVersion
								+ " to "
								+ newVersion
								+ ", only adding Shared table, no data should be destroyed.");
				db.execSQL(SHARED_CREATE);
			} else {
				Log.w(LOG_TAG, "Upgrading database from version " + oldVersion
						+ " to " + newVersion
						+ ", which will destroy all old data");
				db.execSQL("DROP TABLE IF EXISTS notes");
				db.execSQL("DROP TABLE IF EXISTS users");
				db.execSQL("DROP TABLE IF EXISTS shared");
				onCreate(db);
			}
		}

		public void onOpen(SQLiteDatabase db) {
			// db.execSQL("DROP TABLE IF EXISTS notes");
			// db.execSQL(NOTES_CREATE);

			Cursor uCursor = db.rawQuery("SELECT * FROM users", null);
			Cursor nCursor = db.rawQuery("SELECT * FROM notes", null);
			Cursor sCursor = db.rawQuery("SELECT * FROM shared", null);
			Log.i(LOG_TAG, "#USERS: " + uCursor.getCount());
			Log.i(LOG_TAG, "#NOTES: " + nCursor.getCount());
			Log.i(LOG_TAG, "#SHARED NOTES: "+sCursor.getCount());

		}
	}

	public DataCoordinator(Context ctx) {
		this.mCtx = ctx;
	}

	public DataCoordinator open() throws SQLException {

		if (dbHelper == null) {
			Log.v(LOG_TAG, "Creating new database helper");
			dbHelper = new DatabaseHelper(mCtx);
		}

		db = dbHelper.getWritableDatabase();
		return this;
	}

	public void close() {
		dbHelper.close();
	}

	public void resetDatabase(String table) {
		db = dbHelper.getWritableDatabase();
		if (table.equals(NOTES_TABLE)) {
			Log.i(LOG_TAG, "DROPPING TABLE " + table);
			db.execSQL("DROP TABLE IF EXISTS notes");
			db.execSQL(NOTES_CREATE);
		} else if (table.equals(USER_TABLE)) {
			Log.i(LOG_TAG, "DROPPING TABLE " + table);
			db.execSQL("DROP TABLE IF EXISTS users");
			db.execSQL(USERS_CREATE);
		} else if (table.equals("ALL")) {
			Log.i(LOG_TAG, "DROPPING ALL TABLES");
			db.execSQL("DROP TABLE IF EXISTS notes");
			db.execSQL("DROP TABLE IF EXISTS users");
			db.execSQL("DROP TABLE IF EXISTS shared");
			db.execSQL(NOTES_CREATE);
			db.execSQL(USERS_CREATE);
			db.execSQL(SHARED_CREATE);
		}
	}

	// Start of user methods
	public long createUser(String uname, String pass) {
		Log.v(LOG_TAG, "Creating User");

		ContentValues initialValues = new ContentValues();
		initialValues.put(USER_ID, uname);
		initialValues.put(USER_PASS, pass);

		return db.insert(USER_TABLE, null, initialValues);
	}

	public boolean deleteUser(long rowId) {
		return db.delete(USER_TABLE, USER_ROWID + "=" + rowId, null) > 0;
	}

	public Cursor fetchAllUsers() {

		return db.query(USER_TABLE, new String[] { USER_ROWID, USER_ID }, null,
				null, null, null, null);
	}

	public Cursor fetchUser(long rowId) throws SQLException {

		Cursor mCursor = db.query(true, USER_TABLE, new String[] { USER_ROWID,
				USER_ID }, USER_ROWID + "=" + rowId, null, null, null, null,
				null);
		if (mCursor != null) {
			mCursor.moveToFirst();
		}
		return mCursor;

	}

	public boolean updateUser(long rowId, String uname, String pass) {
		ContentValues args = new ContentValues();
		args.put(USER_ID, uname);
		args.put(USER_PASS, pass);

		return db.update(USER_TABLE, args, USER_ROWID + "=" + rowId, null) > 0;
	}

	public int checkUserPass(String uname, String pass) {
		Log.v(LOG_TAG, "Checking user password");

		if (!userExists(uname))
			return 1;

		Cursor mCursor = db.query(USER_TABLE, new String[] { USER_ROWID,
				USER_ID, USER_PASS }, USER_ID + "='" + uname + "'", null, null,
				null, null);

		mCursor.moveToFirst();
		if (mCursor.getString(2).equals(pass))
			return 0;

		return 1;
	}

	public boolean userExists(String uname) {
		Log.v(LOG_TAG, "Checking user password");
		Cursor mCursor = db.query(USER_TABLE, new String[] { USER_ROWID,
				USER_ID, USER_PASS }, USER_ID + "='" + uname + "'", null, null,
				null, null);

		if (mCursor.getCount() != 0)
			return true;

		return false;
	}

	// Start of notes methods
	public long createNote(String title, String body, String owner) {
		Log.v(LOG_TAG, "Creating note " + title);
		ContentValues initialValues = new ContentValues();
		initialValues.put(NOTE_TITLE, title);
		initialValues.put(NOTE_BODY, body);
		initialValues.put(NOTE_OWNER, owner);

		return db.insert(NOTES_TABLE, null, initialValues);
	}

	public boolean deleteNote(long rowId) {

		return db.delete(NOTES_TABLE, NOTE_ROWID + "=" + rowId, null) > 0;
	}

	public Cursor fetchAllNotes() {

		return db.query(NOTES_TABLE, new String[] { NOTE_ROWID, NOTE_TITLE,
				NOTE_BODY, NOTE_OWNER }, null, null, null, null, null);
	}

	public Cursor fetchAllNotesForUser(String user) {
		Cursor mCursor = db.query(true, NOTES_TABLE, new String[] { NOTE_ROWID,
				NOTE_TITLE, NOTE_BODY, NOTE_OWNER }, NOTE_OWNER + "='" + user
				+ "'", null, null, null, null, null, null);
		
//		Cursor mCursor = db.rawQuery(sql, null);
		
		if (mCursor != null) {
			mCursor.moveToFirst();
		}
		return mCursor;
	}
	
	public Cursor fetchAllNotesSharedWithUser(String user_id) {
		String sql = "SELECT notes._id, notes.title, notes.body FROM notes "
				+ "LEFT JOIN shared ON notes._id = shared.note_id "
				+ "WHERE shared.user_id = '"+user_id+"'";
		
		Cursor mCursor = db.rawQuery(sql, null);
		
		if (mCursor != null) {
			mCursor.moveToFirst();
		}
		return mCursor;
	}

	public Cursor fetchNote(long rowId) throws SQLException {

		Cursor mCursor = db.query(true, NOTES_TABLE, new String[] { NOTE_ROWID,
				NOTE_TITLE, NOTE_BODY, NOTE_OWNER }, NOTE_ROWID + "=" + rowId,
				null, null, null, null, null);

		if (mCursor != null) {
			mCursor.moveToFirst();
		}
		return mCursor;

	}

	public boolean updateNote(long rowId, String title, String body) {
		Log.i(LOG_TAG,"Updating Note: "+rowId);

		ContentValues args = new ContentValues();
		args.put(NOTE_TITLE, title);
		args.put(NOTE_BODY, body);

		return db.update(NOTES_TABLE, args, NOTE_ROWID + "=" + rowId, null) > 0;
	}
	
	public boolean userOwnsNote(String user, long note_id){
		Cursor mCursor = db.query(true, NOTES_TABLE, new String[] { NOTE_OWNER },
				NOTE_ROWID + "=" + note_id, null, null, null, null, null);
		
		if (mCursor != null) {
			mCursor.moveToFirst();
			return mCursor.getString(0).compareToIgnoreCase(user) == 0;
		}
		return false;
	}
	
	
	public long addShare(long note_id, String user_id){
		ContentValues initialValues = new ContentValues();
		initialValues.put(SHARED_NID, note_id);
		initialValues.put(SHARED_UID, user_id);
		
		return db.insert(SHARED_TABLE, null, initialValues);
	}
	
	public boolean removeShare(long note_id, String user_id){
		return db.delete(SHARED_TABLE, 
				SHARED_NID + "=" + note_id + " AND "+ SHARED_UID + " = '" + user_id + "'",
				null) > 0;
	}
	
	public boolean noteSharedWithUser(long note_id, String user_id){
		Cursor c = db.query(true, SHARED_TABLE, new String[] { SHARED_ROWID }, 
				SHARED_NID + "=" + note_id + " AND "+ SHARED_UID + " = '" + user_id + "'", 
				null, null, null, null, null);
		
		if (c.getCount() > 0)
			return true;
		
		return false;
	}
	
	public ArrayList<String> usersForNote(long note_id){
		Cursor mCursor = db.query(true, SHARED_TABLE, new String[] { SHARED_UID },
				SHARED_NID + "=" + note_id, null, null, null, null, null);
		
		ArrayList<String> retVal = new ArrayList<String>(mCursor.getCount());
		
		if (mCursor != null) {
			mCursor.moveToFirst();
			while(!mCursor.isAfterLast()){
				retVal.add(mCursor.getString(0));
				mCursor.moveToNext();
			}
		}
		
		return retVal;
	}
}
