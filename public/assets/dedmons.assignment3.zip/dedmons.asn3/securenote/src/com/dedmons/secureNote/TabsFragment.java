package com.dedmons.secureNote;

import android.app.Activity;
import android.os.Bundle;
import android.support.v4.app.Fragment;
import android.support.v4.app.FragmentManager;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TabHost;
import android.widget.TabHost.OnTabChangeListener;
import android.widget.TabHost.TabSpec;
import android.widget.TextView;


public class TabsFragment extends Fragment implements OnTabChangeListener {

	public static final String TAB_OWN_NOTES = "Own Notes";
	public static final String TAB_SHARED_NOTES = "Shared Notes";
	
	private View mainView;
	private TabHost tabHost;
	private int currentTab;
	
	@Override
	public void onAttach(Activity activity) {
		super.onAttach(activity);
	}
	
	@Override
	public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
		mainView = inflater.inflate(R.layout.tabs_fragment, null);
		tabHost = (TabHost) mainView.findViewById(android.R.id.tabhost);
		setupTabs();
		return mainView;
	}
	
	@Override
	public void onActivityCreated(Bundle savedInstanceState) {
		super.onActivityCreated(savedInstanceState);
		setRetainInstance(true);
		
		tabHost.setOnTabChangedListener(this);
		tabHost.setCurrentTab(currentTab);
		
		// start loading stuff in the first tab
		updateTab(TAB_OWN_NOTES, R.id.my_tab);
	}
	
	public void setupTabs() {
		tabHost.setup();
		tabHost.addTab(newTab(TAB_OWN_NOTES, R.string.tab_own, R.id.my_tab));
		tabHost.addTab(newTab(TAB_SHARED_NOTES, R.string.tab_shared, R.id.shared_tab));
	}
	
	private TabSpec newTab(String tabTag, int labelID, int tabContentID) {
		View indicator = LayoutInflater.from( getActivity()).inflate( R.layout.tab, (ViewGroup) mainView.findViewById(android.R.id.tabs), false );
		((TextView) indicator.findViewById(R.id.text)).setText(labelID);
		
		TabSpec newTab = tabHost.newTabSpec(tabTag);
		newTab.setIndicator(indicator);
		newTab.setContent(tabContentID);
		return newTab;
	}
	
	@Override
	public void onTabChanged(String tabId) {
		if ( TAB_OWN_NOTES.equals(tabId) ) {
			updateTab(tabId, R.id.my_tab);
			currentTab = 0;
			return;
		}
		if ( TAB_SHARED_NOTES.equals(tabId) ) {
			updateTab(tabId, R.id.shared_tab);
			currentTab = 1;
			return;
		}
	}
	
	private void updateTab(String tabID, int placeHolder) {
		FragmentManager fm = getFragmentManager();
		if ( fm.findFragmentByTag(tabID) == null ) {
			Log.i("Tab","tabID "+ tabID);
			fm.beginTransaction().replace(placeHolder, new MyListFragment(tabID), tabID).commit();
		}
	}

}