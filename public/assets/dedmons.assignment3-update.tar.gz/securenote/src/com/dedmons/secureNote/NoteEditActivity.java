package com.dedmons.secureNote;

import java.util.ArrayList;

import android.app.Activity;
import android.app.AlertDialog;
import android.app.Dialog;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.SharedPreferences.Editor;
import android.database.Cursor;
import android.os.Bundle;
import android.provider.Settings.Secure;
import android.support.v4.app.NavUtils;
import android.util.Log;
import android.view.KeyEvent;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.view.Window;
import android.widget.EditText;
import android.widget.Toast;

public class NoteEditActivity extends Activity {
	private static final String LOG_TAG = "com.dedmons.asn1-NoteEditActivity";
	private static final String PREFS = "com.dedmons.asn1-PREFS";

	private DataCoordinator ds;
	private String user;
	private String noteID;

	ArrayList<String> shareUsers;
	ArrayList<Integer> shareUserIDs;
	boolean[] usersChecked;

	ArrayList<String> usersSharedWith;

	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		requestWindowFeature(Window.FEATURE_NO_TITLE);
		setContentView(R.layout.activity_note_edit);
		// Show the Up button in the action bar.
		// getActionBar().setDisplayHomeAsUpEnabled(true);

		ds = new DataCoordinator(this);
		ds.open();

		SharedPreferences prefs = getSharedPreferences(PREFS, 0);
		user = prefs.getString("uname", "*");
		noteID = prefs.getString("NoteID", "new");

		Editor ed = prefs.edit();
		ed.remove("NoteID");
		ed.commit();

		Intent i = getIntent();

		Log.i(LOG_TAG, "NoteID from Prefs: " + noteID);

		EditText t = (EditText) findViewById(R.id.titleArea);
		t.setText(i.getStringExtra("noteTitle"));

		EditText e = (EditText) findViewById(R.id.textArea);
		e.setText(i.getStringExtra("noteText"));

		if (!noteID.equalsIgnoreCase("New"))
			usersSharedWith = ds.usersForNote(Long.valueOf(noteID));
		else
			usersSharedWith = new ArrayList<String>();

		Log.i(LOG_TAG, "Users Shared With: " + usersSharedWith);

		Cursor c = ds.fetchAllUsers();
		if (c.getCount() > 0) {
			shareUsers = new ArrayList<String>(c.getCount() - 1);
			shareUserIDs = new ArrayList<Integer>(c.getCount() - 1);
			usersChecked = new boolean[c.getCount() - 1];

			c.moveToFirst();
			String s;
			while (!c.isAfterLast()) {
				s = c.getString(1);
				if (!s.equalsIgnoreCase(user)) {
					Log.i(LOG_TAG, "Adding " + s + " to share list");
					shareUsers.add(s);
					shareUserIDs.add(c.getInt(0));

					if (usersSharedWith.contains(s)) {
						usersChecked[usersSharedWith.indexOf(s)] = true;
					}

				}
				c.moveToNext();
			}
		} else {
			shareUsers = new ArrayList<String>(0);
			shareUserIDs = new ArrayList<Integer>(0);
			usersChecked = new boolean[0];
		}

		Log.i(LOG_TAG, "Share Users size: " + shareUsers.size());
		Log.i(LOG_TAG, "Share Users list: " + shareUsers);
	}

	@Override
	public boolean onCreateOptionsMenu(Menu menu) {
		// Inflate the menu; this adds items to the action bar if it is present.
		getMenuInflater().inflate(R.menu.activity_note_edit, menu);
		return true;
	}

	@Override
	public boolean onOptionsItemSelected(MenuItem item) {

		switch (item.getItemId()) {
		case android.R.id.home:
			NavUtils.navigateUpFromSameTask(this);
			return true;
		case R.id.share:
			showDialog(0);
			return true;
		case R.id.delete:
			showDialog(1);
			return true;
		}
		return super.onOptionsItemSelected(item);
	}

	protected Dialog onCreateDialog(int id) {
		switch (id) {
		case 0:
			return new AlertDialog.Builder(this)
					.setIcon(R.drawable.ic_launcher)
					.setTitle("Dialog with simple text")
					.setPositiveButton("OK",
							new DialogInterface.OnClickListener() {

								@Override
								public void onClick(DialogInterface dialog,
										int which) {
									for (int i = 0; i < shareUsers.size() - 1; i++) {
										if (usersChecked[i]) {
											Toast.makeText(
													getBaseContext(),
													shareUsers.get(i)
															+ " checked!",
													Toast.LENGTH_SHORT).show();
										}
									}
								}
							})
					.setNegativeButton("Cancel",
							new DialogInterface.OnClickListener() {

								@Override
								public void onClick(DialogInterface dialog,
										int which) {
									Toast.makeText(getBaseContext(),
											"Canceled", Toast.LENGTH_SHORT)
											.show();
								}
							})
					.setMultiChoiceItems(
							shareUsers.toArray(new CharSequence[0]),
							usersChecked,
							new DialogInterface.OnMultiChoiceClickListener() {

								@Override
								public void onClick(DialogInterface dialog,
										int which, boolean isChecked) {
									Log.v(LOG_TAG, "Is Checked: " + isChecked);
									if (isChecked) {
										usersSharedWith.add(shareUsers
												.get(which));
									} else {
										usersSharedWith.remove(shareUsers
												.get(which));
									}
								}
							}).create();
		case 1:
			return new AlertDialog.Builder(this)
					.setIcon(R.drawable.ic_launcher)
					.setTitle("Are you sure?")
					.setPositiveButton("Delete Note",
							new DialogInterface.OnClickListener() {
								@Override
								public void onClick(DialogInterface dialog,
										int which) {
									if (!ds.userOwnsNote(user,
											Long.valueOf(noteID))) {
										Toast.makeText(getBaseContext(),
												"You are not the owner",
												Toast.LENGTH_LONG).show();
									} else {
										if (noteID.equalsIgnoreCase("New"))
											cancelNote(null);
										else
											ds.deleteNote(Long.valueOf(noteID));
									}
								}
							}).setNegativeButton("Cancel", null).create();
		}

		return null;
	}

	public void cancelNote(View v) {
		Log.v(LOG_TAG, "Cancel Note");
		Toast t = Toast.makeText(getApplicationContext(), "Note Canceled",
				Toast.LENGTH_SHORT);
		t.show();
		startActivity(new Intent(this, NoteListActivity.class));
		finish();
	}

	public void saveNote(View v) {
		Log.v(LOG_TAG, "Save Note with ID: " + noteID);

		String noteTitle = ((EditText) findViewById(R.id.titleArea)).getText()
				.toString();
		String noteText = ((EditText) findViewById(R.id.textArea)).getText()
				.toString();
		String android_id = Secure.getString(getBaseContext()
				.getContentResolver(), Secure.ANDROID_ID);
		String noteTextCrypt = SimpleCrypto.encrypt(android_id, noteText);

		long res = 0;
		if (noteID.compareTo("new") == 0) {
			Log.v(LOG_TAG, "Saving New Note");
			res = ds.createNote(noteTitle, noteTextCrypt, user);

			if (res != -1) {
				long id = res;
				for (String user : usersSharedWith) {
					res = ds.addShare(id, user) != -1 ? res : -1;
				}

				// Log.i(LOG_TAG,"Shared Users: "+usersSharedWith);
			}
		} else if (ds.userOwnsNote(user, Long.valueOf(noteID))) {
			Log.v(LOG_TAG, "Saving Note " + noteID);
			boolean r = ds.updateNote(Long.valueOf(noteID), noteTitle,
					noteTextCrypt);

			if (r) {
				// Log.i(LOG_TAG,"Shared Users: "+usersSharedWith);

				for (String user : shareUsers) {
					if (ds.noteSharedWithUser(Long.valueOf(noteID), user)) {
						if (!usersSharedWith.contains(user))
							r = ds.removeShare(Long.valueOf(noteID), user);
					} else {
						if (usersSharedWith.contains(user))
							r = ds.addShare(Long.valueOf(noteID), user) != -1;
					}
				}
			} else {
				Toast.makeText(getApplicationContext(), "Not allowed to save",
						Toast.LENGTH_LONG).show();
			}

			res = r ? 1 : -1;
		}

		Toast t;
		if (res == -1)
			t = Toast.makeText(getApplicationContext(),
					"Error with saving note", Toast.LENGTH_SHORT);
		else
			t = Toast.makeText(getApplicationContext(), "Note Saved",
					Toast.LENGTH_SHORT);
		t.show();

		startActivity(new Intent(this, NoteListActivity.class));
		finish();
	}

	@Override
	public void onBackPressed() {
		Log.i(LOG_TAG, "Back Pressed");
		startActivity(new Intent(this, NoteListActivity.class));
		finish();
	}

	@Override
	public boolean onKeyDown(int keyCode, KeyEvent event) {
		if (keyCode == KeyEvent.KEYCODE_BACK) {

			Log.i(LOG_TAG, "Back Key");
			startActivity(new Intent(this, NoteListActivity.class));
			finish();

		} else if (keyCode == KeyEvent.KEYCODE_MENU) {
			Log.i(LOG_TAG, "Menu Key");
			openOptionsMenu();
		}
		return true;
	}
}
